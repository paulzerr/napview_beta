#!/usr/bin/env python
from src.napview.core.napview_backend import main as backend_main

if __name__ == "__main__":
    backend_main()
